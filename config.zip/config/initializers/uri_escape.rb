module URI
  def URI.escape(url)
    url
  end
end
